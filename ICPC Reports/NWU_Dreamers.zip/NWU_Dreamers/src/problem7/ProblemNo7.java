/*
 * ProblemSet - 7
 */
package problem7;

import java.util.Scanner;

/**
 * @author NWU_Dreamers
 *
 */
public class ProblemNo7 {

	public static void main(String[] args) {

		Scanner read = new Scanner(System.in);
		
		int n = read.nextInt();
		long arr[] = new long[n];
		long max = 0;
		
		for(int i=0; i<n; i++) {
			arr[i] = read.nextLong();
			if(arr[i]>max) {
				max = arr[i];
			}
		}
		System.out.println(max);
		
		read.close();
	}
}
